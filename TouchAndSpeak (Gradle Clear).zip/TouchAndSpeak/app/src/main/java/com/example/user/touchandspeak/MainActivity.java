package com.example.user.touchandspeak;

import android.content.Intent;
import android.net.Uri;
import android.provider.CallLog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import com.example.user.touchandspeak.R;

import java.util.List;

import static com.example.user.touchandspeak.R.id.info;

public class MainActivity extends AppCompatActivity {
Button b1;
   MyDBHandler myDBHandler;
    ImageButton h;
    ImageButton i;
    Button pbutton;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myDBHandler = new MyDBHandler(this, null, null, 1);



      //  b1= (Button)findViewById(R.id.button);
        i=(ImageButton)findViewById(R.id.combutton);
       /* b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,Third.class));
            }
        });*/
        h=(ImageButton)findViewById(R.id.historybutton);
        h.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, History.class);
                List<Calc> history = myDBHandler.readHistory();
                String output = "" + history.size() + "\n";
                for (Calc row : history) {
                    output += row.toString();
                }

                intent.putExtra("history", output);

                startActivity(intent);
            }
        });
        i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,Third.class));
            }
        });





    }
    public  void emergency(View view){
        Intent intent=new Intent(MainActivity.this,emergencynumber.class);
        startActivity(intent);

    }
    public void phone(View view){
       // String number1 =myDBHandler.;
        String msg ="Emergency !! ";
        Intent smsIntent = new Intent(Intent.ACTION_VIEW);
        smsIntent.setType("vnd.android-dir/mms-sms");
        //smsIntent.putExtra("address", number1);
        smsIntent.putExtra("sms_body",msg);
        finish();
        startActivity(smsIntent);
    }
    public void signlanguage(View view){

        Intent intent=new Intent(MainActivity.this,SignLanguage.class);
        startActivity(intent);
    }
    public void paint(View view){
        Intent intent=new Intent(MainActivity.this,paint.class);
        startActivity(intent);

    }
    public void how(View view){
        Intent intent=new Intent(MainActivity.this,How.class);
        startActivity(intent);
    }
    public void call(View view){

       /* Intent intent=new Intent(MainActivity.this,call.class);
        startActivity(intent);*/
        String smsText = "Plz help me!! ";
        // String smsNumber = e1.getNumbertosave();
        final String lastCalledNumber = CallLog.Calls.getLastOutgoingCall(getApplicationContext());
        Uri uri = Uri.parse("smsto:" + lastCalledNumber);
        Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
        intent.putExtra("sms_body", smsText);
        try {
            startActivity(intent);
        }catch(Exception e){
            e.printStackTrace();
        }





    }
  /*  public void onClickHistory(View view) {
        Intent intent = new Intent(this, History.class);
        List<Calc> history = myDBHandler.readHistory();
        String output = "" + history.size() + "\n";
        for (Calc row : history) {
            output += row.toString();
        }

        intent.putExtra("history", output);

        startActivity(intent);

    }*/
}
