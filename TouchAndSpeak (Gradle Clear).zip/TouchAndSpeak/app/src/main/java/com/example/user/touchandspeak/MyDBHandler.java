package com.example.user.touchandspeak;

/**
 * Created by User on 2/6/2017.
 */
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by sakib on 1/15/17.
 */

public class MyDBHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "calculator.db";
    private static final String TABLE_HISTORY = "history";
    private static final String COLUMN_ID = "_id";

    private static final String COLUMN_ACTION = "action";//price
    private static final String COLUMN_TIME = "time";//price


    private static final String COLUMN_PHONE = "phone";
    private static final String COLUMN_TRANSPORT = "transport";//price
    private static final String COLUMN_GROCERY = "grocery";//price
    private static final String COLUMN_ANSWER = "answer";



    public MyDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String query = "CREATE TABLE " + TABLE_HISTORY + " ( " +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT ," +
                COLUMN_ACTION + " TEXT ," +
                COLUMN_TIME + " TEXT ," +
                COLUMN_TRANSPORT+ " INTEGER ," +
                COLUMN_GROCERY + " INTEGER ," +
                COLUMN_ANSWER + " INTEGER ," +
                COLUMN_PHONE + " TEXT " +
                ");";
        sqLiteDatabase.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS" + TABLE_HISTORY +";");
        onCreate(sqLiteDatabase);
    }


    public void addHistory(Calc calc) {
        String query = "INSERT INTO " + TABLE_HISTORY +
                "(" + COLUMN_ACTION +"," + COLUMN_TIME +")" +
                "VALUES" +
                "( \"" + calc.getAction() +"\",\""+ calc.getTime()+ "\");";
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL(query);
    }
    public void addHistoryPhone(Calc calc) {
        String query = "INSERT INTO " + TABLE_HISTORY +
                "(" + COLUMN_PHONE +")" +
                "VALUES" +
                "( \"" + calc.getPhone() + "\");";
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL(query);
    }






    public List<Calc> readHistory() {
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_HISTORY;

        Cursor cursor = db.rawQuery(query, null);
        cursor.moveToFirst();
        List<Calc> history = new ArrayList<>();
        while(!cursor.isAfterLast()) {
            Calc calc = new Calc();
            calc.set_id(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
            calc.setAction(cursor.getString(cursor.getColumnIndex(COLUMN_ACTION)));
            calc.setTime(cursor.getString(cursor.getColumnIndex(COLUMN_TIME)));
            calc.setPhone(cursor.getString(cursor.getColumnIndex(COLUMN_PHONE)));

            history.add(calc);
            cursor.moveToNext();
        }
        return history;
    }
/*
    public String getPhoneNumber()
    {
        SQLiteDatabase db = getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_HISTORY;
        String phoneNo= "NULL";
        Cursor cursor = db.rawQuery(query, null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast()) {
            phoneNo = cursor.getString(cursor.getColumnIndex(COLUMN_PHONE));
            break;
        }
        db.close();
        return phoneNo;
    }*/

}
