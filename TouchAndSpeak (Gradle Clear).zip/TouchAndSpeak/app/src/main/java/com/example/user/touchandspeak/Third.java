

package com.example.user.touchandspeak;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.media.MediaPlayer;
import android.content.res.AssetFileDescriptor;
import android.widget.ImageButton;

import java.io.IOException;
import java.util.Calendar;

public class Third extends AppCompatActivity {
private ImageButton b1,b2,b3,b4,b5,b6,b7,b8,b9;
    ImageButton bb1;
    String action ,time;
    MyDBHandler myDBHandler;
    Button b;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
        myDBHandler = new MyDBHandler(this, null, null, 1);
        bb1= (ImageButton)findViewById(R.id.button7);
        bb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Third.this,Third2.class));
            }
        });
        b=(Button)findViewById(R.id.button6);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Third.this,MainActivity.class));
            }
        });


        final MediaPlayer mp1 = new MediaPlayer();
        final MediaPlayer mp2 = new MediaPlayer();
        final MediaPlayer mp3 = new MediaPlayer();
        final MediaPlayer mp4 = new MediaPlayer();


        ImageButton b7 = (ImageButton) findViewById(R.id.imageButton4);//water
        ImageButton b5 = (ImageButton) findViewById(R.id.imageButton5);//wash
        ImageButton b6 = (ImageButton) findViewById(R.id.imageButton3);//bell
        ImageButton b8 = (ImageButton) findViewById(R.id.imageButton2);// food



        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


               action= "Water";
               // String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);




                if(mp1.isPlaying())
                {
                    mp1.stop();
                }
                try {
                    mp1.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("water.mp3");
                    mp1.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp1.prepare();
                    mp1.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                action= "washroom";
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);
                if(mp2.isPlaying())
                {
                    mp2.stop();
                }
                try {
                    mp2.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("washroom.mp3");
                    mp2.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp2.prepare();
                    mp2.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                action= "Bell";
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);
                if(mp3.isPlaying())
                {
                    mp3.stop();
                }
                try {
                    mp3.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("bell.mp3");
                    mp3.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp3.prepare();
                    mp3.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                action= "Food";
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);
                if(mp4.isPlaying())
                {
                    mp4.stop();
                }
                try {
                    mp4.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("hungry.mp3");
                    mp4.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp4.prepare();
                    mp4.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });







    }
}
