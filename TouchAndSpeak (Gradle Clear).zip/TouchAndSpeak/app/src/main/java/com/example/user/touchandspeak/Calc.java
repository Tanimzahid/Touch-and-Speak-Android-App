package com.example.user.touchandspeak;

/**
 * Created by User on 2/6/2017.
 */
public class Calc {
    int _id;
    String operation;
    String action;
    String time;
    String phone;
    // int transport;
    //int grocery;
    //int answer;

    public Calc() {
    }

    public Calc(String action, String time) {
        setAction(action);
        setTime(time);

        // setGrocery(grocery);
        //setTransport(transport);
        //setAnswer(c);
        //setOperation(op);
    }
    public Calc( String Phone) {

        setPhone(Phone);

        // setGrocery(grocery);
        //setTransport(transport);
        //setAnswer(c);
        //setOperation(op);
    }

    @Override
    public String toString() {
        return "" + _id + " " + action + " " + time + "\n";
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

/*
    public int getAction() {
        return action;
    }

    public void setAction(int action) {
        this.action = action;
    }

    public int getTime() {
        return time;
    }

    public void setTime(int time) {
        this.time = time;
    }*/
    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
    public void setPhone(String Phone){this.phone=Phone;}
    public String getPhone(){return phone;}


}