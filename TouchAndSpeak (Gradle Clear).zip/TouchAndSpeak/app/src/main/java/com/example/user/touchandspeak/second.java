package com.example.user.touchandspeak;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;



public class second extends AppCompatActivity  {
    ImageButton b2,b3,paintbutton;
    Button b4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        b2= (ImageButton)findViewById(R.id.needsbutton);
        b3= (ImageButton)findViewById(R.id.callbutton);
        b4= (Button)findViewById(R.id.button3);
        paintbutton= (ImageButton)findViewById(R.id.pbutton);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(second.this,Third.class));
            }
        });
       b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               //startActivity(new Intent(second.this,call.class));
                Intent intent = new Intent(Intent.ACTION_DIAL);
                intent.setData(Uri.parse("tel:"+emergencynumber.getNumbertosave()));
                startActivity(intent);



            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(second.this,emergencynumber.class));
            }
        });
        paintbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(second.this,paint.class));
            }
        });



    }
}
