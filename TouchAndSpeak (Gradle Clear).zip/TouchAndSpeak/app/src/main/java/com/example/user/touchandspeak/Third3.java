package com.example.user.touchandspeak;

import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.io.IOException;
import java.util.Calendar;

public class Third3 extends AppCompatActivity {
    ImageButton bb3;
    Button c;
    String action ,time;
    MyDBHandler myDBHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third3);
        myDBHandler = new MyDBHandler(this, null, null, 1);
        bb3= (ImageButton)findViewById(R.id.imageButton22);
        bb3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Third3.this,Third4.class));
            }
        });
        c=(Button)findViewById(R.id.button9);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Third3.this,MainActivity.class));
            }
        });

        final MediaPlayer mp14 = new MediaPlayer();
        final MediaPlayer mp15 = new MediaPlayer();
        final MediaPlayer mp16 = new MediaPlayer();
        final MediaPlayer mp17 = new MediaPlayer();
        ImageButton b1 = (ImageButton) findViewById(R.id.imageButton4);//flu
        ImageButton b2 = (ImageButton) findViewById(R.id.imageButton5);//headache
        ImageButton b3 = (ImageButton) findViewById(R.id.imageButton3);//fever
        ImageButton b4 = (ImageButton) findViewById(R.id.imageButton2);// bellyache


        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                action= "Flu";
                // String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);




                if(mp14.isPlaying())
                {
                    mp14.stop();
                }
                try {
                    mp14.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("sick.mp3");
                    mp14.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp14.prepare();
                    mp14.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        });



        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                action= "HeadAche";
                // String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);




                if(mp15.isPlaying())
                {
                    mp15.stop();
                }
                try {
                    mp15.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("matha betha.mp3");
                    mp15.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp15.prepare();
                    mp15.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                action= "Fever";
                // String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);




                if(mp16.isPlaying())
                {
                    mp16.stop();
                }
                try {
                    mp16.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("oshustho lagche.mp3");
                    mp16.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp16.prepare();
                    mp16.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                action= "Belly Ache";
                // String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);




                if(mp17.isPlaying())
                {
                    mp17.stop();
                }
                try {
                    mp17.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("pet betha korche.mp3");
                    mp17.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp17.prepare();
                    mp17.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        });


    }
}
