package com.example.user.touchandspeak;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class Third4 extends AppCompatActivity {
    ImageButton bb4;
    Button cc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third4);


        bb4= (ImageButton)findViewById(R.id.imageButton24);
        bb4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Third4.this,Third.class));
            }
        });
        cc=(Button)findViewById(R.id.button10);
        cc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Third4.this,MainActivity.class));
            }
        });
    }
}
