package com.example.user.touchandspeak;


import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageAdapter extends BaseAdapter {

    private Context context;
    public Integer[] images={
            R.drawable.bathroom,R.drawable.boy,
            R.drawable.bye,R.drawable.food,
            R.drawable.hello,R.drawable.friday,
            R.drawable.help,R.drawable.my,
            R.drawable.hungry,R.drawable.love,
            R.drawable.no,R.drawable.please,
            R.drawable.qstn,R.drawable.sorry,
            R.drawable.thank,R.drawable.want,
            R.drawable.yes,R.drawable.friday,
            R.drawable.wednesday,R.drawable.thursday
    };

    public ImageAdapter(Context c){
        context =c;

    }


    @Override
    public int getCount() {
        return images.length;
    }

    @Override
    public Object getItem(int position) {
        return images[position];
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup viewGroup) {

        ImageView imageView=new ImageView(context);
        imageView.setImageResource(images[position]);
        imageView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        imageView.setLayoutParams(new GridView.LayoutParams(240,240));
        return imageView;
    }
}
