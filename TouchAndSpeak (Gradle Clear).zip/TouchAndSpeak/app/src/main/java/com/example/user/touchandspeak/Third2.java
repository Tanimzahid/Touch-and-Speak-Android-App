package com.example.user.touchandspeak;

import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.io.IOException;
import java.util.Calendar;

public class Third2 extends AppCompatActivity {
    ImageButton bb2;
    String action ,time;
    MyDBHandler myDBHandler;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third2);
        myDBHandler = new MyDBHandler(this, null, null, 1);
        bb2= (ImageButton)findViewById(R.id.imageButton23);
        bb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Third2.this,Third3.class));
            }
        });
        b1=(Button)findViewById(R.id.button8);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Third2.this,MainActivity.class));
            }
        });

        final MediaPlayer mp5 = new MediaPlayer();
        final MediaPlayer mp6 = new MediaPlayer();
        final MediaPlayer mp7 = new MediaPlayer();
        final MediaPlayer mp8 = new MediaPlayer();

        final MediaPlayer mp9 = new MediaPlayer();
        final MediaPlayer mp10 = new MediaPlayer();
        final MediaPlayer mp11 = new MediaPlayer();
        final MediaPlayer mp12 = new MediaPlayer();
        final MediaPlayer mp13 = new MediaPlayer();

        ImageButton b9 = (ImageButton) findViewById(R.id.imageButton4);//chicken
        ImageButton b10 = (ImageButton) findViewById(R.id.imageButton7);//icecream
        ImageButton b11 = (ImageButton) findViewById(R.id.imageButton8);//burger
        ImageButton b12 = (ImageButton) findViewById(R.id.imageButton6);// fruits

        ImageButton b13 = (ImageButton) findViewById(R.id.imageButton5);//choco
        ImageButton b14 = (ImageButton) findViewById(R.id.imageButton9);//mango
        ImageButton b15 = (ImageButton) findViewById(R.id.imageButton10);//pizza
        ImageButton b16 = (ImageButton) findViewById(R.id.imageButton11);// khichuri

        ImageButton b17 = (ImageButton) findViewById(R.id.imageButton12);// friedrice





        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                action= "Chicken";
                // String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);




                if(mp5.isPlaying())
                {
                    mp5.stop();
                }
                try {
                    mp5.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("chicken.mp3");
                    mp5.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp5.prepare();
                    mp5.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }


            }
        });
        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                action= "icecream";
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);
                if(mp6.isPlaying())
                {
                    mp6.stop();
                }
                try {
                    mp6.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("ice cream khabo.mp3");
                    mp6.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp6.prepare();
                    mp6.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });
        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                action= "burger";
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);
                if(mp7.isPlaying())
                {
                    mp7.stop();
                }
                try {
                    mp7.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("burger khabo.mp3");
                    mp7.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp7.prepare();
                    mp7.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });
        b12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                action= "Fruits";
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);
                if(mp8.isPlaying())
                {
                    mp8.stop();
                }
                try {
                    mp8.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("fol khabo.mp3");
                    mp8.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp8.prepare();
                    mp8.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });
        b13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                action= "chocolate";
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);
                if(mp9.isPlaying())
                {
                    mp9.stop();
                }
                try {
                    mp9.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("chocolate khabo.mp3");
                    mp9.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp9.prepare();
                    mp9.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });
        b14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                action= "Mangoe";
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);
                if(mp10.isPlaying())
                {
                    mp10.stop();
                }
                try {
                    mp10.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("fol khabo.mp3");
                    mp10.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp10.prepare();
                    mp10.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });
        b15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                action= "Pizza";
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);
                if(mp11.isPlaying())
                {
                    mp11.stop();
                }
                try {
                    mp11.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("pizza khabo.mp3");
                    mp11.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp11.prepare();
                    mp11.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });



        b16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                action= "Khichuri";
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);
                if(mp12.isPlaying())
                {
                    mp12.stop();
                }
                try {
                    mp12.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("khichuri khabo.mp3");
                    mp12.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp12.prepare();
                    mp12.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });
        b17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                action= "Friedrice";
                String mydate = java.text.DateFormat.getDateTimeInstance().format(Calendar.getInstance().getTime()).toString();
                time=mydate;
                Calc calc = new Calc(action,time);
                myDBHandler.addHistory(calc);
                if(mp13.isPlaying())
                {
                    mp13.stop();
                }
                try {
                    mp13.reset();
                    AssetFileDescriptor afd;
                    afd = getAssets().openFd("bhat khabo.mp3");
                    mp13.setDataSource(afd.getFileDescriptor(),afd.getStartOffset(),afd.getLength());
                    mp13.prepare();
                    mp13.start();
                } catch (IllegalStateException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }



            }
        });



    }
}
