package com.example.user.touchandspeak;

import android.Manifest;

import android.net.Uri;
import android.provider.CallLog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.view.View;
import android.content.Intent;
import android.content.pm.PackageManager;


import android.support.v4.app.ActivityCompat;

public class call extends AppCompatActivity {
private Button cbutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call);

     //   setContentView(R.layout.activity_main);


       cbutton = (Button) findViewById(R.id.button14);

        cbutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
               /* Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:01687711284"));

                if (ActivityCompat.checkSelfPermission(call.this,
                        Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                startActivity(callIntent);*/
                emergencynumber e1 =new emergencynumber();
                String smsText = "Plz help me!! ";
               // String smsNumber = e1.getNumbertosave();
                final String lastCalledNumber = CallLog.Calls.getLastOutgoingCall(getApplicationContext());
                Uri uri = Uri.parse("smsto:" + lastCalledNumber);
                Intent intent = new Intent(Intent.ACTION_SENDTO, uri);
                intent.putExtra("sms_body", smsText);
               try {
                   startActivity(intent);
               }catch(Exception e){
                   e.printStackTrace();
               }

              /*  Intent intent  = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + lastCalledNumber));*/

            }
        });






    }
}
