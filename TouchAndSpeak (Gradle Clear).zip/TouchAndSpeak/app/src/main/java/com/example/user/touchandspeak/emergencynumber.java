package com.example.user.touchandspeak;

import android.content.Intent;
import android.provider.CallLog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class emergencynumber extends AppCompatActivity {
Button savebutton;
EditText e1;
  static   String numbertosave;
    MyDBHandler myDBHandler;

    public void onResume(Bundle savedInstanceState)
    {
        String lastCalledNumber = CallLog.Calls.getLastOutgoingCall(this);
        numbertosave= lastCalledNumber;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergencynumber);
        myDBHandler = new MyDBHandler(this, null, null, 1);
       



       // numbertosave= lastCalledNumber;


        savebutton= (Button)findViewById(R.id.button2);
        e1= (EditText)findViewById(R.id.editText2);
        savebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int size = e1.getText().length();
                if(size==11)
                {
                    numbertosave= e1.getText().toString();
                    startActivity(new Intent(emergencynumber.this,MainActivity.class));
                }
                Calc calc = new Calc(e1.getText().toString());
                myDBHandler.addHistory(calc);



            }
        });






    }
   static  String getNumbertosave()
    {
        return numbertosave;
    }


}
